sqlite3 pets.db < create_db.sql


